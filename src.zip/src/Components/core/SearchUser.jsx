import React from 'react'

const SearchUser = () => {
  return (
    <div>SearchUser</div>
  )
}

export default SearchUser