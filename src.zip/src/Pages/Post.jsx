import React from 'react'
import CreatePost from '../Components/Posts/CreatePost'

const Post = () => {
  return (
    <CreatePost/>
  )
}

export default Post